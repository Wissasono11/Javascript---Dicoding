function fibonacci(n) {
  // Basis: jika n adalah 0 atau 1, kembalikan n
  if (n === 0 || n === 1) return n;

  // Rekursif: kembalikan fibonacci dari n-1 dan n-2
  return fibonacci(n - 1) + fibonacci(n - 2);
}

// Jangan hapus kode di bawah ini!
export default fibonacci;
